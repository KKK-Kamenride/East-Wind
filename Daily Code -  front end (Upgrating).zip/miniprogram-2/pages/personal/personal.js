// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data:{
    isShow: false,
  },

  onLoad(){
      if(isShow){
        //已经授过权
        this.setData({
          isShow: true
        })
      }
  },

  getUser(){
    let that = this;
    wx.getUserProfile({
      desc: '为了学分',  //获取用户信息的理由
      success(res){
          let userinfo = res.userInfo;
          that.setData({
            isShow: true,
          userinfo:userinfo
          })
          wx.setStorageSync('isShow', true)
      },
      fail(){
        wx.showToast({
          title: '拜托啦，这对我真的很重要~',
          icon: 'none'
        })
      }
    })
  }
})