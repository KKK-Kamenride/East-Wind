// pages/home/home.js
var util = require('../../utils/util.js'); //参数是util.js所在的路径，参照自个儿的
 
Page({

  onUnload: function() {
    //销毁定时器
    clearInterval(this.data.timer);
  },

  onLoad: function () {
    // 调用函数时，传入new Date()参数，返回值是日期和时间
    var currenTime= util.formatTime(new Date());
    // 再通过setData更改Page()里面的data，动态更新页面的数据
    this.setData({
      currenTime: currenTime
    });
  },
 


  toBegin:function (params) {
      wx.navigateTo({
        url: '../help/help',
      })
  },
  toBegin1:function (params){
      wx.navigateTo({
        url: '../Catalogue/Catalogue',
      })
  },
  toBegin2:function (params) {
      wx.navigateTo({
        url: '../game/game',
      })
  },
  toBegin3:function (params) {
      wx.navigateTo({
        url: '../New/New',
      })
  },

  toBegin4:function (params) {
    wx.navigateTo({
      url: '../award/award',
    })
  }

})