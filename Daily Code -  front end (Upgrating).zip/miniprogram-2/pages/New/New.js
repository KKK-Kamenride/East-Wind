// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  toBegin:function (params) {
      wx.switchTab({
        url: '../home/home',
      })
  },

  toBegin2:function (params) {
      wx.navigateTo({
        url: '../game/game',
      })
  },
  toBegin3:function (params) {
      wx.navigateTo({
        url: '../join/join',
      })
  },

  toBegin4:function (params) {
    wx.navigateTo({
      url: '../award/award',
    })
  },

  toBegin1:function (params){
    wx.switchTab({
      url: '../home/home',
    })
},
})