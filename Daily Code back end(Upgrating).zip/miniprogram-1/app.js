App({
  //小程序启动就执行
  onLaunch() {
    console.log("小程序启动了")
    wx.cloud.init({
      env:"ee308-4gj7dv1n6bfbb0f7"//云开发环境id
    })
  }
})
