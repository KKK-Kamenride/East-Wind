// pages/yunhanshu/yunhanshu.js
Page({

  onLoad() {
//用云函数做简单的加法
wx.cloud.callFunction({
  name:"add1119"
})
    
    // //云函数获取数据
    // wx.cloud.callFunction({
    //   name:"getData",
    // })
    // .then(res=>{
    //   console.log('云函数获取数据成功',res)
    // })
    // .catch(res=>{
    //   console.log('云函数获取数据失败',res)
    // })

    // //数据库获取数据
    // wx.cloud.database().collection('num').get()
    // .then(res=>{
    //   console.log('数据库获取数据成功',res)
    // })
    // .catch(res=>{
    //   console.log('数据库数据失败',res)
    // })
  }
})