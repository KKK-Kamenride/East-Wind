// pages/skip/skip.js
Page({

  onLoad: function (options) {
    wx.cloud.database().collection('num')
    .limit(2)
    .skip(2)
    .get()
    .then(res=>{
      console.log('请求成功',res)
    })
    .catch(res=>{
      console.log('请求失败',res)
    })
  }
})