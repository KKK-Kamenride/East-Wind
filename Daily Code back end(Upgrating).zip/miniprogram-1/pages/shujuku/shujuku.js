// pages/shujuku/shujuku.js
Page({
  data:{
    list:[],
    good:{}
  },
  onLoad(){
    //es6简洁写法
    wx.cloud.database().collection('goods')
    // .where({
    //   name:'苹果'
    // })
    .get()
      .then(res=>{
        //请求成功
        console.log("返回的数据",res)
        this.setData({
          list:res.data
        })
      })
      .catch(err=>{
        //请求失败
        console.log("第二种请求失败",err)
      })
  //使用doc查询单条数据
    wx.cloud.database().collection('goods')
    .doc('859059a56198901106f185ba129368ba')//苹果
    .get()
    .then(res=>{
      //请求成功
      console.log("查询单条",res.data)
      this.setData({
        good:res.data
      })
    })
    .catch(err=>{
      //请求失败
      console.log("查询单条失败",err)
    })
  }
})