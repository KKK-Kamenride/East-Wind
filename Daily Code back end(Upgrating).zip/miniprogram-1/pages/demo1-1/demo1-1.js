// pages/demo1-1/demo1-1.js
let price = ""
var id = ''
Page({
  data: {
    good: {}
  },

  onLoad(options) {
    console.log('列表携带的值', options)
    id = options.id
    this.getDetail()


},
  //获取商品数据
  getDetail() {
    wx.cloud.database().collection('goods')
      .doc(id)
      .get()
      .then(res => {
        console.log('商品详情成功', res)
        this.setData({
          good: res.data
        })
      })
      .catch(res => {
        console.log('商品详情失败', res)
      })
  },
  //获取用户输入的新价格
  getPrice(e) {
    price = e.detail.value
  },
  update() {
    console.log('新的商品价格', price)
    if (price == '') {
      wx.showToast({
        icon: 'none',
        title: '价格为空',
      })
    } else {
      //本地小程序直接调用数据库更新商品价格
      // wx.cloud.database().collection('goods')
      //   .doc(id)
      //   .update({
      //     data: {
      //       price: price
      //     }
      //   })
      //   .then(res => {
      //     console.log('更新成功', res)
      //     this.getDetail()
      //   })
      //   .catch(res => {
      //     console.log('更新失败', res)
      //   })
      
      //调用云函数更新商品价格
      wx.cloud.callFunction({
        name:"update1119",
        data:{
          id:id,
          price:parseInt(price)
        }
      }).then(res => {
        console.log('调用云函数成功', res)
        this.getDetail()
      }).catch(res => {
        console.log('调用云函数失败', res)
      })
    }
  },
  //删除操作
  shanchu() {
    console.log('点击删除', id)
    //弹窗提示
    wx.showModal({
      title: "是否确定删除",
      content: "删除后将无法找回",
      success(res) {
        if (res.confirm == true) {
          console.log("用户点击了删除")
          // wx.cloud.database().collection('goods')
          //   .doc(id)
          //   .remove()

          wx.cloud.callFunction({
            name:"remove",
            data:{
              id:id
            }
          }).then(res => {
              console.log('删除成功', res)
              wx.navigateTo({
                url: '/pages/demo1/demo1',
              })
            })
            .catch(res => {
              console.log('删除失败', res)
            })
        } else if (res.cancel == true) {
          console.log("用户点击了取消")
        }
      }
    })
  }
})